#include <stdio.h>

#include "SDL.h"

int main(int argc, char *argv[]) {
  int i = 10;
  float f = 3.145634;

  printf("%f\n", ((int)(f * 100.0))/100.0);
  printf("%f\n", sinf(4));
}
